import random
import string
import logging
import hashlib

from locust import HttpLocust, TaskSet, task

logger = logging.getLogger(__name__)

class GetImagesBehavior(TaskSet):
    @task(1)
    def get_image(self):
        n = 10
        with open('/Users/jaumepinyol/Documents/locust/locust/tests/pre-sample.txt') as f:
            for url in f:
                with self.client.get(url.strip(), catch_response=True) as response:

                    if 'image-md5' in response.headers:
                        origin_md5 = response.headers['image-md5']
                        logger.info("md5 header:%s", origin_md5)
                        m = hashlib.md5()
                        m.update(response.content)
                        md5 = m.hexdigest()
                        logger.info("md5 header:%s == %s", origin_md5, md5)

                        if origin_md5 != md5:
                            logger.error("Url: %s doesn't match md5", url.strip())
                            filename = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(n))
                            filename = "{}/{}.{}".format("tests/images", filename, "jpg")
                            logger.info("filename %s", filename)
                            with open(filename, 'wb') as image_file:
                                image_file.write(response.content)
                                image_file.flush()
                                image_file.close()
                            response.failure("Md5 does not match")

                    else:
                        response.failure("md5 missing")
        f.close()


class WebsiteUser(HttpLocust):
    task_set = GetImagesBehavior
    min_wait = 5000
    max_wait = 9000
