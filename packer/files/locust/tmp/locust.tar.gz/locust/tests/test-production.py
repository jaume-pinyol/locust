import random
import string
from locust import HttpLocust, TaskSet, task
import logging
import hashlib

logger = logging.getLogger(__name__)
n = 10


def create_file(content):
    filename = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(n))
    filename = "{}/{}.{}".format("/tmp/images", filename, "jpg")
    logger.info("filename %s", filename)
    with open(filename, 'wb') as image_file:
        image_file.write(content)
        image_file.flush()
        image_file.close()


class GetImagesBehavior(TaskSet):
    @task(1)
    def get_image(self):
        with open('/Users/jaumepinyol/Documents/locust/locust/tests/production-sample.txt') as f:

            for url in f:
                with self.client.get(url.strip(), catch_response=True) as response:

                    if 'image-md5' in response.headers:
                        origin_md5 = response.headers['image-md5']
                        m = hashlib.md5()
                        m.update(response.content)
                        md5 = m.hexdigest()

                        if origin_md5 != md5:
                            logger.error("Url: %s md5 header:%s != %s" % (url.strip(), origin_md5, md5))
                            create_file(response.content)
                            response.failure("Md5 does not match")

                    else:
                        logger.error("url: %s failed", url.strip())
                        response.failure("md5 missing")
        f.close()


class WebsiteUser(HttpLocust):
    task_set = GetImagesBehavior
    min_wait = 5000
    max_wait = 9000
